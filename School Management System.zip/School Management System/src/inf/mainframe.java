
package inf;

import codes.DBconnect;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class mainframe extends javax.swing.JFrame {
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

   
    public mainframe() {
        initComponents();
        conn = DBconnect.connect();       
        stableload();
    }

   
     
    public void stableload(){
        try {
            String sql = "SELECT id AS ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo, courseName AS CourseName FROM student";
            pst = conn.prepareStatement(sql); 
            rs = pst.executeQuery(); 
            
            table3.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
   
    
    public void stabledata(){
        
        int r = table3.getSelectedRow();
              
        
        String sid = table3.getValueAt(r, 0).toString();
        String sfname = table3.getValueAt(r, 1).toString();
        String sname = table3.getValueAt(r, 2).toString();
        String snic = table3.getValueAt(r, 3).toString();
        String sgender = table3.getValueAt(r, 4).toString();
        String saddress = table3.getValueAt(r, 5).toString();
        String sphone = table3.getValueAt(r, 6).toString();
        String scname = table3.getValueAt(r, 7).toString();
        String scphone = table3.getValueAt(r, 8).toString(); 
        String scoursename = table3.getValueAt(r, 9).toString();
         
        
        sidbox.setText(sid);
        sfnamebox.setText(sfname);
        snamebox.setText(sname);
        snicbox.setText(snic);
        
        if (sgender.equals("Male")) {
             smalebox.setSelected(true);
        } else {
            sfemalebox.setSelected(true);
        }
        
        saddressbox.setText(saddress);
        sphonebox.setText(sphone);
        scnamebox.setText(scname);
        scphonebox.setText(scphone);
        scorsenamebox.setSelectedItem(scoursename);
        
                  
    }
    
   
   
    
     public void ssearch(){
    String srch = ssearchbox.getText();
    
    //run sql query
        try {
            String sql = "SELECT * FROM student WHERE id LIKE'%"+srch+"%'  OR fname LIKE '%"+srch+"%' OR namei LIKE '%"+srch+"%' OR nic LIKE '%"+srch+"%' OR gender LIKE '%"+srch+"%' OR address LIKE '%"+srch+"%' OR phoneno LIKE '%"+srch+"%' OR cname LIKE '%"+srch+"%' OR ctpn LIKE'%"+srch+"%' OR courseName LIKE'%"+srch+"%' ";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            table3.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
     
      
    public void supdate(){
    
        //create 4 variable
        String sid = sidbox.getText();        
        String sfname = sfnamebox.getText();    
        String snamei = snamebox.getText();
        String snic = snicbox.getText();
        
        String sgender = "";

    // Check if the "MALE" radio button is selected
            if (smalebox.isSelected()) {
                sgender = "Male";
            }   
            else if (sfemalebox.isSelected()) {
               sgender = "Female";    
            }
    
    
        String saddress = saddressbox.getText();
        String sphone = sphonebox.getText();        
        String scname = snamebox.getText();
        String sctpn = scphonebox.getText();
        String scoursen = scorsenamebox.getSelectedItem().toString();
        
        //value assign using update quety
        
        try {
            String sql = "UPDATE student SET fname= '"+sfname+"', namei= '"+snamei+"',  nic = '"+snic+"' ,  gender = '"+sgender+"' ,  address = '"+saddress+"'  ,  phoneno = '"+sphone+"' ,  cname = '"+scname+"' ,  ctpn = '"+sctpn+"' ,courseName = '"+scoursen+"'  WHERE id = '"+sid+"'";
            pst = conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Data updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
  
     
    
    public  void sclear(){
        ssearchbox.setText("");
        sidbox.setText("");
        sfnamebox.setText("");
        snamebox.setText("");
        snicbox.setText("");
        sgendergrp.clearSelection();
        saddressbox.setText("");
        sphonebox.setText("");  
        scnamebox.setText("");  
        scphonebox.setText("");  
        scorsenamebox.setSelectedIndex(0);
                  
    }
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gendergrp = new javax.swing.ButtonGroup();
        sgendergrp = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        logoutbtn1 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table3 = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        sfnamebox = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        ssearchbox = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        snamebox = new javax.swing.JTextField();
        snicbox = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        saddressbox = new javax.swing.JTextField();
        sphonebox = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        scorsenamebox = new javax.swing.JComboBox();
        jLabel23 = new javax.swing.JLabel();
        sfemalebox = new javax.swing.JRadioButton();
        smalebox = new javax.swing.JRadioButton();
        jLabel24 = new javax.swing.JLabel();
        scnamebox = new javax.swing.JTextField();
        scphonebox = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        sidbox = new javax.swing.JTextField();
        sinsertbtn = new javax.swing.JButton();
        supdatebtn = new javax.swing.JButton();
        sclearbtn = new javax.swing.JButton();
        sdeletebtn = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        hairbeautybtn = new javax.swing.JButton();
        fasiondesignbtn = new javax.swing.JButton();
        ictbtn = new javax.swing.JButton();
        englishbtn = new javax.swing.JButton();
        tmilbtn = new javax.swing.JButton();
        japanbtn = new javax.swing.JButton();
        cookbtn = new javax.swing.JButton();
        bridalbtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        viewbtn1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        icttbl = new javax.swing.JTable();
        backbt1 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        english = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        englishtbl = new javax.swing.JTable();
        backbt8 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        tamil = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tamilbtn = new javax.swing.JTable();
        backbt2 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        hb = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        hbtbl = new javax.swing.JTable();
        backbt3 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        bridal = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        bridaltbl = new javax.swing.JTable();
        backbt4 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        cook = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        cooktbl = new javax.swing.JTable();
        backbt5 = new javax.swing.JButton();
        jPanel16 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        japan = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        japantbl = new javax.swing.JTable();
        backbt6 = new javax.swing.JButton();
        jPanel17 = new javax.swing.JPanel();
        jPanel23 = new javax.swing.JPanel();
        fd = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        fdtbl = new javax.swing.JTable();
        backbt7 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 102, 102));
        jButton3.setText("View Course");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 480, 130, 40));

        jButton4.setBackground(new java.awt.Color(255, 255, 255));
        jButton4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(0, 102, 102));
        jButton4.setText("Add Student");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 130, 40));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inf/lg.png"))); // NOI18N
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 0, 280, 260));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 770));

        jPanel5.setBackground(new java.awt.Color(0, 102, 102));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Hobo Std", 0, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("ABC ACADEMY");
        jPanel5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 60, -1, -1));

        logoutbtn1.setBackground(new java.awt.Color(255, 255, 255));
        logoutbtn1.setFont(new java.awt.Font("SansSerif", 1, 22)); // NOI18N
        logoutbtn1.setForeground(new java.awt.Color(255, 255, 255));
        logoutbtn1.setText("Home");
        logoutbtn1.setContentAreaFilled(false);
        logoutbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtn1ActionPerformed(evt);
            }
        });
        jPanel5.add(logoutbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 60, 130, 40));

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1310, 120));

        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        table3.setForeground(new java.awt.Color(0, 102, 102));
        table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "St ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "GUARDIAN'S NAME", "GUARDIAN'S TP NO", "COURSE NAME"
            }
        ));
        table3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table3MouseClicked(evt);
            }
        });
        table3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                table3KeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(table3);

        jPanel11.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 1000, 150));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 102, 102));
        jLabel16.setText("Students' Details");
        jPanel11.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 10, 290, 62));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 102, 102));
        jLabel17.setText("Full Name");
        jPanel11.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 130, 42));

        sfnamebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        sfnamebox.setForeground(new java.awt.Color(0, 102, 102));
        sfnamebox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sfnameboxActionPerformed(evt);
            }
        });
        jPanel11.add(sfnamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 310, 322, 42));

        jPanel12.setBackground(new java.awt.Color(0, 102, 102));
        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "SEARCH", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 13), new java.awt.Color(255, 255, 255))); // NOI18N
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ssearchbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ssearchboxActionPerformed(evt);
            }
        });
        ssearchbox.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ssearchboxKeyReleased(evt);
            }
        });
        jPanel12.add(ssearchbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 370, 40));

        jPanel11.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 10, 410, 80));

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 102, 102));
        jLabel18.setText("Name with Initials");
        jPanel11.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 360, 170, 42));

        snamebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        snamebox.setForeground(new java.awt.Color(0, 102, 102));
        jPanel11.add(snamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 360, 322, 42));

        snicbox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        snicbox.setForeground(new java.awt.Color(0, 102, 102));
        snicbox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                snicboxActionPerformed(evt);
            }
        });
        jPanel11.add(snicbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 410, 322, 42));

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 102, 102));
        jLabel19.setText("Gender");
        jPanel11.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 130, 42));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 102, 102));
        jLabel20.setText("Address");
        jPanel11.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 260, 130, 42));

        saddressbox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        saddressbox.setForeground(new java.awt.Color(0, 102, 102));
        jPanel11.add(saddressbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 260, 322, 42));

        sphonebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        sphonebox.setForeground(new java.awt.Color(0, 102, 102));
        jPanel11.add(sphonebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 310, 322, 42));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 102, 102));
        jLabel21.setText("Phone No");
        jPanel11.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 310, 130, 42));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 102, 102));
        jLabel22.setText("Course Name");
        jPanel11.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 460, 130, 42));

        scorsenamebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        scorsenamebox.setForeground(new java.awt.Color(0, 102, 102));
        scorsenamebox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "ICT", "English", "Tamil", "Hair & Beauty", "Bridal", "Cookery", "Japan", "Fasion Design" }));
        jPanel11.add(scorsenamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 460, 320, 40));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 102, 102));
        jLabel23.setText("NIC No");
        jPanel11.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 130, 42));

        sgendergrp.add(sfemalebox);
        sfemalebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        sfemalebox.setForeground(new java.awt.Color(0, 102, 102));
        sfemalebox.setText("Female");
        jPanel11.add(sfemalebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 460, -1, -1));

        sgendergrp.add(smalebox);
        smalebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        smalebox.setForeground(new java.awt.Color(0, 102, 102));
        smalebox.setText("Male");
        smalebox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                smaleboxActionPerformed(evt);
            }
        });
        jPanel11.add(smalebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 460, -1, -1));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 102, 102));
        jLabel24.setText("Guardian's Name");
        jPanel11.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 360, 170, 42));

        scnamebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        scnamebox.setForeground(new java.awt.Color(0, 102, 102));
        jPanel11.add(scnamebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 360, 322, 42));

        scphonebox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        scphonebox.setForeground(new java.awt.Color(0, 102, 102));
        jPanel11.add(scphonebox, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 410, 322, 42));

        jLabel25.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 102, 102));
        jLabel25.setText("Guardian's TP No");
        jPanel11.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 410, 170, 42));

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(0, 102, 102));
        jLabel29.setText("St ID");
        jPanel11.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 130, 42));

        sidbox.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        sidbox.setForeground(new java.awt.Color(0, 102, 102));
        jPanel11.add(sidbox, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 322, 42));

        sinsertbtn.setBackground(new java.awt.Color(0, 102, 102));
        sinsertbtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sinsertbtn.setForeground(new java.awt.Color(255, 255, 255));
        sinsertbtn.setText("INSERT");
        sinsertbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sinsertbtnActionPerformed(evt);
            }
        });
        jPanel11.add(sinsertbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 520, -1, -1));

        supdatebtn.setBackground(new java.awt.Color(0, 102, 102));
        supdatebtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        supdatebtn.setForeground(new java.awt.Color(255, 255, 255));
        supdatebtn.setText("UPDATE");
        supdatebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                supdatebtnActionPerformed(evt);
            }
        });
        jPanel11.add(supdatebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 520, -1, -1));

        sclearbtn.setBackground(new java.awt.Color(0, 102, 102));
        sclearbtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sclearbtn.setForeground(new java.awt.Color(255, 255, 255));
        sclearbtn.setText("CLEAR");
        sclearbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sclearbtnActionPerformed(evt);
            }
        });
        jPanel11.add(sclearbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 520, -1, -1));

        sdeletebtn.setBackground(new java.awt.Color(0, 102, 102));
        sdeletebtn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        sdeletebtn.setForeground(new java.awt.Color(255, 255, 255));
        sdeletebtn.setText("DELETE");
        sdeletebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sdeletebtnActionPerformed(evt);
            }
        });
        jPanel11.add(sdeletebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 520, -1, -1));

        jPanel7.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1080, 620));

        jTabbedPane1.addTab("Stud", jPanel7);

        jPanel14.setBackground(new java.awt.Color(255, 255, 255));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 102, 102));
        jLabel3.setText("Course Details");
        jPanel14.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 270, 230, 62));

        hairbeautybtn.setBackground(new java.awt.Color(255, 255, 255));
        hairbeautybtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        hairbeautybtn.setForeground(new java.awt.Color(0, 102, 102));
        hairbeautybtn.setText("Hair & Beauty");
        hairbeautybtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hairbeautybtnActionPerformed(evt);
            }
        });
        jPanel14.add(hairbeautybtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 440, 200, 50));

        fasiondesignbtn.setBackground(new java.awt.Color(255, 255, 255));
        fasiondesignbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        fasiondesignbtn.setForeground(new java.awt.Color(0, 102, 102));
        fasiondesignbtn.setText("Fasion Design");
        fasiondesignbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fasiondesignbtnActionPerformed(evt);
            }
        });
        jPanel14.add(fasiondesignbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 110, 200, 50));

        ictbtn.setBackground(new java.awt.Color(255, 255, 255));
        ictbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        ictbtn.setForeground(new java.awt.Color(0, 102, 102));
        ictbtn.setText("ICT");
        ictbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ictbtnActionPerformed(evt);
            }
        });
        jPanel14.add(ictbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 180, 200, 50));

        englishbtn.setBackground(new java.awt.Color(255, 255, 255));
        englishbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        englishbtn.setForeground(new java.awt.Color(0, 102, 102));
        englishbtn.setText("English");
        englishbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishbtnActionPerformed(evt);
            }
        });
        jPanel14.add(englishbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 280, 200, 50));

        tmilbtn.setBackground(new java.awt.Color(255, 255, 255));
        tmilbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        tmilbtn.setForeground(new java.awt.Color(0, 102, 102));
        tmilbtn.setText("Tamil");
        tmilbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tmilbtnActionPerformed(evt);
            }
        });
        jPanel14.add(tmilbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 380, 200, 50));

        japanbtn.setBackground(new java.awt.Color(255, 255, 255));
        japanbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        japanbtn.setForeground(new java.awt.Color(0, 102, 102));
        japanbtn.setText("Japan");
        japanbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                japanbtnActionPerformed(evt);
            }
        });
        jPanel14.add(japanbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 180, 200, 50));

        cookbtn.setBackground(new java.awt.Color(255, 255, 255));
        cookbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        cookbtn.setForeground(new java.awt.Color(0, 102, 102));
        cookbtn.setText("Cookery");
        cookbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cookbtnActionPerformed(evt);
            }
        });
        jPanel14.add(cookbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 280, 200, 50));

        bridalbtn.setBackground(new java.awt.Color(255, 255, 255));
        bridalbtn.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        bridalbtn.setForeground(new java.awt.Color(0, 102, 102));
        bridalbtn.setText("Bridal");
        bridalbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bridalbtnActionPerformed(evt);
            }
        });
        jPanel14.add(bridalbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 380, 200, 50));

        jTabbedPane1.addTab("CD", jPanel14);

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        viewbtn1.setBackground(new java.awt.Color(255, 255, 255));
        viewbtn1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        viewbtn1.setForeground(new java.awt.Color(0, 102, 102));
        viewbtn1.setText("View Details");
        viewbtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewbtn1ActionPerformed(evt);
            }
        });
        jPanel15.add(viewbtn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 102, 102));
        jLabel4.setText("ICT Course Details");
        jPanel15.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 30, 310, 62));

        icttbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        icttbl.setForeground(new java.awt.Color(0, 102, 102));
        icttbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        icttbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                icttblMouseClicked(evt);
            }
        });
        icttbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                icttblKeyReleased(evt);
            }
        });
        jScrollPane7.setViewportView(icttbl);

        jPanel15.add(jScrollPane7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt1.setBackground(new java.awt.Color(255, 255, 255));
        backbt1.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt1.setForeground(new java.awt.Color(0, 102, 102));
        backbt1.setText("Back");
        backbt1.setContentAreaFilled(false);
        backbt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt1ActionPerformed(evt);
            }
        });
        jPanel15.add(backbt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Ict", jPanel4);

        jPanel25.setBackground(new java.awt.Color(255, 255, 255));
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        english.setBackground(new java.awt.Color(255, 255, 255));
        english.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        english.setForeground(new java.awt.Color(0, 102, 102));
        english.setText("View Details");
        english.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                englishActionPerformed(evt);
            }
        });
        jPanel25.add(english, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 102, 102));
        jLabel12.setText("English Course Details");
        jPanel25.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 30, 360, 62));

        englishtbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        englishtbl.setForeground(new java.awt.Color(0, 102, 102));
        englishtbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        englishtbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                englishtblMouseClicked(evt);
            }
        });
        englishtbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                englishtblKeyReleased(evt);
            }
        });
        jScrollPane15.setViewportView(englishtbl);

        jPanel25.add(jScrollPane15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt8.setBackground(new java.awt.Color(255, 255, 255));
        backbt8.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt8.setForeground(new java.awt.Color(0, 102, 102));
        backbt8.setText("Back");
        backbt8.setContentAreaFilled(false);
        backbt8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt8ActionPerformed(evt);
            }
        });
        jPanel25.add(backbt8, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel6Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("English", jPanel6);

        jPanel18.setBackground(new java.awt.Color(255, 255, 255));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tamil.setBackground(new java.awt.Color(255, 255, 255));
        tamil.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        tamil.setForeground(new java.awt.Color(0, 102, 102));
        tamil.setText("View Details");
        tamil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tamilActionPerformed(evt);
            }
        });
        jPanel18.add(tamil, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 102, 102));
        jLabel5.setText("Tamil Course Details");
        jPanel18.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 30, 390, 62));

        tamilbtn.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        tamilbtn.setForeground(new java.awt.Color(0, 102, 102));
        tamilbtn.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        tamilbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tamilbtnMouseClicked(evt);
            }
        });
        tamilbtn.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tamilbtnKeyReleased(evt);
            }
        });
        jScrollPane8.setViewportView(tamilbtn);

        jPanel18.add(jScrollPane8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt2.setBackground(new java.awt.Color(255, 255, 255));
        backbt2.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt2.setForeground(new java.awt.Color(0, 102, 102));
        backbt2.setText("Back");
        backbt2.setContentAreaFilled(false);
        backbt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt2ActionPerformed(evt);
            }
        });
        jPanel18.add(backbt2, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Tamil", jPanel8);

        jPanel19.setBackground(new java.awt.Color(255, 255, 255));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        hb.setBackground(new java.awt.Color(255, 255, 255));
        hb.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        hb.setForeground(new java.awt.Color(0, 102, 102));
        hb.setText("View Details");
        hb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hbActionPerformed(evt);
            }
        });
        jPanel19.add(hb, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 102));
        jLabel6.setText("Hair & Beauty Course Details");
        jPanel19.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, 480, 62));

        hbtbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        hbtbl.setForeground(new java.awt.Color(0, 102, 102));
        hbtbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        hbtbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hbtblMouseClicked(evt);
            }
        });
        hbtbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                hbtblKeyReleased(evt);
            }
        });
        jScrollPane9.setViewportView(hbtbl);

        jPanel19.add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt3.setBackground(new java.awt.Color(255, 255, 255));
        backbt3.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt3.setForeground(new java.awt.Color(0, 102, 102));
        backbt3.setText("Back");
        backbt3.setContentAreaFilled(false);
        backbt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt3ActionPerformed(evt);
            }
        });
        jPanel19.add(backbt3, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel19, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Hair&Beauty", jPanel9);

        jPanel20.setBackground(new java.awt.Color(255, 255, 255));
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        bridal.setBackground(new java.awt.Color(255, 255, 255));
        bridal.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        bridal.setForeground(new java.awt.Color(0, 102, 102));
        bridal.setText("View Details");
        bridal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bridalActionPerformed(evt);
            }
        });
        jPanel20.add(bridal, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 102, 102));
        jLabel7.setText("Bridal Course Details");
        jPanel20.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 30, 380, 62));

        bridaltbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        bridaltbl.setForeground(new java.awt.Color(0, 102, 102));
        bridaltbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        bridaltbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bridaltblMouseClicked(evt);
            }
        });
        bridaltbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                bridaltblKeyReleased(evt);
            }
        });
        jScrollPane10.setViewportView(bridaltbl);

        jPanel20.add(jScrollPane10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt4.setBackground(new java.awt.Color(255, 255, 255));
        backbt4.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt4.setForeground(new java.awt.Color(0, 102, 102));
        backbt4.setText("Back");
        backbt4.setContentAreaFilled(false);
        backbt4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt4ActionPerformed(evt);
            }
        });
        jPanel20.add(backbt4, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel10Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel10Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel20, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Bridal", jPanel10);

        jPanel21.setBackground(new java.awt.Color(255, 255, 255));
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cook.setBackground(new java.awt.Color(255, 255, 255));
        cook.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        cook.setForeground(new java.awt.Color(0, 102, 102));
        cook.setText("View Details");
        cook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cookActionPerformed(evt);
            }
        });
        jPanel21.add(cook, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 102));
        jLabel8.setText("Cookery Course Details");
        jPanel21.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 30, 380, 62));

        cooktbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        cooktbl.setForeground(new java.awt.Color(0, 102, 102));
        cooktbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        cooktbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cooktblMouseClicked(evt);
            }
        });
        cooktbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                cooktblKeyReleased(evt);
            }
        });
        jScrollPane11.setViewportView(cooktbl);

        jPanel21.add(jScrollPane11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt5.setBackground(new java.awt.Color(255, 255, 255));
        backbt5.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt5.setForeground(new java.awt.Color(0, 102, 102));
        backbt5.setText("Back");
        backbt5.setContentAreaFilled(false);
        backbt5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt5ActionPerformed(evt);
            }
        });
        jPanel21.add(backbt5, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel13Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel13Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Cook", jPanel13);

        jPanel22.setBackground(new java.awt.Color(255, 255, 255));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        japan.setBackground(new java.awt.Color(255, 255, 255));
        japan.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        japan.setForeground(new java.awt.Color(0, 102, 102));
        japan.setText("View Details");
        japan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                japanActionPerformed(evt);
            }
        });
        jPanel22.add(japan, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 102, 102));
        jLabel9.setText("Japan Course Details");
        jPanel22.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, 340, 62));

        japantbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        japantbl.setForeground(new java.awt.Color(0, 102, 102));
        japantbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        japantbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                japantblMouseClicked(evt);
            }
        });
        japantbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                japantblKeyReleased(evt);
            }
        });
        jScrollPane12.setViewportView(japantbl);

        jPanel22.add(jScrollPane12, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt6.setBackground(new java.awt.Color(255, 255, 255));
        backbt6.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt6.setForeground(new java.awt.Color(0, 102, 102));
        backbt6.setText("Back");
        backbt6.setContentAreaFilled(false);
        backbt6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt6ActionPerformed(evt);
            }
        });
        jPanel22.add(backbt6, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel16Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel16Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Japan", jPanel16);

        jPanel23.setBackground(new java.awt.Color(255, 255, 255));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fd.setBackground(new java.awt.Color(255, 255, 255));
        fd.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        fd.setForeground(new java.awt.Color(0, 102, 102));
        fd.setText("View Details");
        fd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fdActionPerformed(evt);
            }
        });
        jPanel23.add(fd, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 510, -1, -1));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 102, 102));
        jLabel10.setText("Fashion Design Course Details");
        jPanel23.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 30, 480, 62));

        fdtbl.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        fdtbl.setForeground(new java.awt.Color(0, 102, 102));
        fdtbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ST ID", "FULL NAME", "NAME WITH INITIALS", "NIC NO", "GENDER", "ADDRESS", "PHONE NO", "CUSTODIANS NAME", "CUSTODIANS TP NO", "COURSE NAME"
            }
        ));
        fdtbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                fdtblMouseClicked(evt);
            }
        });
        fdtbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                fdtblKeyReleased(evt);
            }
        });
        jScrollPane13.setViewportView(fdtbl);

        jPanel23.add(jScrollPane13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 1040, 320));

        backbt7.setBackground(new java.awt.Color(255, 255, 255));
        backbt7.setFont(new java.awt.Font("SansSerif", 1, 20)); // NOI18N
        backbt7.setForeground(new java.awt.Color(0, 102, 102));
        backbt7.setText("Back");
        backbt7.setContentAreaFilled(false);
        backbt7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbt7ActionPerformed(evt);
            }
        });
        jPanel23.add(backbt7, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 130, 40));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1145, Short.MAX_VALUE)
            .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel17Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, 1145, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 622, Short.MAX_VALUE)
            .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel17Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel23, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Fasiondesign", jPanel17);

        jPanel2.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 120, 1150, 650));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1370, 770));

        setSize(new java.awt.Dimension(1316, 799));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void logoutbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtn1ActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        allinf home = new allinf();
        home.setVisible(true);
    }//GEN-LAST:event_logoutbtn1ActionPerformed

    private void backbt8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt8ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt8ActionPerformed

    private void englishtblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_englishtblKeyReleased
        // TODO add your handling code here:
        
    }//GEN-LAST:event_englishtblKeyReleased

    private void englishtblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_englishtblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_englishtblMouseClicked

    private void englishActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS  ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'English' "; //create query (table eke display kirimata awashya title pamanak add kala haka.
                pst = conn.prepareStatement(sql); //connect variables
                rs = pst.executeQuery(); // connect variables

                englishtbl.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_englishActionPerformed

    private void backbt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt1ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt1ActionPerformed

    private void icttblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_icttblKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_icttblKeyReleased

    private void icttblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_icttblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_icttblMouseClicked

    private void viewbtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewbtn1ActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS  ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'ICT' ";
                pst = conn.prepareStatement(sql); //connect variables
                rs = pst.executeQuery(); // connect variables

                icttbl.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_viewbtn1ActionPerformed

    private void bridalbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bridalbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_bridalbtnActionPerformed

    private void cookbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cookbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(7);
    }//GEN-LAST:event_cookbtnActionPerformed

    private void japanbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_japanbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(8);
    }//GEN-LAST:event_japanbtnActionPerformed

    private void tmilbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tmilbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_tmilbtnActionPerformed

    private void englishbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_englishbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_englishbtnActionPerformed

    private void ictbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ictbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_ictbtnActionPerformed

    private void fasiondesignbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fasiondesignbtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(9);
    }//GEN-LAST:event_fasiondesignbtnActionPerformed

    private void hairbeautybtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hairbeautybtnActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_hairbeautybtnActionPerformed

    private void sdeletebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sdeletebtnActionPerformed
        // TODO add your handling code here:
        int check = JOptionPane.showConfirmDialog(null,"Do you wont to delete");//conform message
        //yes = 0 / no = 1 / cancle = 2
        if(check == 0){
            String id = sidbox.getText();

            try {
                String sql = "DELETE FROM student WHERE id = '"+id+"'";
                pst = conn.prepareStatement(sql); //run query
                pst.execute(); // run query
                JOptionPane.showMessageDialog(null,"Deleted");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
        }
        stableload();
        sclear();
    }//GEN-LAST:event_sdeletebtnActionPerformed

    private void sclearbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sclearbtnActionPerformed
        // TODO add your handling code here:
        sclear();
        stableload();
    }//GEN-LAST:event_sclearbtnActionPerformed

    private void supdatebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_supdatebtnActionPerformed
        // TODO add your handling code here:
        supdate();
        stableload();
    }//GEN-LAST:event_supdatebtnActionPerformed

    private void sinsertbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sinsertbtnActionPerformed
        // TODO add your handling code here:
        int sid;
        String sfname;
        String sname;
        String snic;
        String sgender;
        String saddress;
        String sphone;
        String scname;
        int scptn;
        String scourseName;

        //value asingn
        sid = Integer.parseInt(sidbox.getText());
        sfname = sfnamebox.getText();
        sname = snamebox.getText();
        snic = snicbox.getText();

        if (smalebox.isSelected()) {
            sgender = "Male";
        } else {
            sgender = "Female";
        }

        saddress = saddressbox.getText();
        sphone = sphonebox.getText();
        scname= scnamebox.getText();
        scptn= Integer.parseInt(scphonebox.getText());
        scourseName = (String)scorsenamebox.getSelectedItem();

        //how to add  value in database

        try {
            String sql = "INSERT INTO student (id,fname,namei,nic,gender,address,phoneno,cname,ctpn,courseName) VALUE ('"+sid+"','"+sfname+"' ,'"+sname+"' ,'"+snic+"' ,'"+sgender+"' ,'"+saddress+"','"+sphone+"','"+scname+"','"+scptn+"','"+scourseName+"')"; 
            pst = conn.prepareStatement(sql); //run query
            pst.execute(); // run query
            JOptionPane.showMessageDialog(null, "Data Inserted");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        stableload();
        sclear();
    }//GEN-LAST:event_sinsertbtnActionPerformed

    private void ssearchboxKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ssearchboxKeyReleased
        // TODO add your handling code here:
        ssearch();
    }//GEN-LAST:event_ssearchboxKeyReleased

    private void ssearchboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ssearchboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ssearchboxActionPerformed

    private void table3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_table3KeyReleased
        // TODO add your handling code here:
        stabledata();
    }//GEN-LAST:event_table3KeyReleased

    private void table3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table3MouseClicked
        // TODO add your handling code here:
        stabledata();
    }//GEN-LAST:event_table3MouseClicked

    private void tamilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tamilActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS  ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'Tamil' "; 
                pst = conn.prepareStatement(sql); 
                rs = pst.executeQuery(); 

                tamilbtn.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_tamilActionPerformed

    private void tamilbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tamilbtnMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tamilbtnMouseClicked

    private void tamilbtnKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tamilbtnKeyReleased
        // TODO add your handling code here:
        
    }//GEN-LAST:event_tamilbtnKeyReleased

    private void backbt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt2ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt2ActionPerformed

    private void hbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hbActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName='Hair & Beauty' "; //create query (table eke display kirimata awashya title pamanak add kala haka.
                pst = conn.prepareStatement(sql); 
                rs = pst.executeQuery(); 

                hbtbl.setModel(DbUtils.resultSetToTableModel(rs));// 
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_hbActionPerformed

    private void hbtblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hbtblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_hbtblMouseClicked

    private void hbtblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hbtblKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_hbtblKeyReleased

    private void backbt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt3ActionPerformed

    private void bridalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bridalActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS  ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'Bridal' ";
                pst = conn.prepareStatement(sql); //connect variables
                rs = pst.executeQuery(); // connect variables

                bridaltbl.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_bridalActionPerformed

    private void bridaltblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bridaltblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_bridaltblMouseClicked

    private void bridaltblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_bridaltblKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_bridaltblKeyReleased

    private void backbt4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt4ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt4ActionPerformed

    private void cookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cookActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS  ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'Cookery' "; 
                pst = conn.prepareStatement(sql); //connect variables
                rs = pst.executeQuery(); // connect variables

                cooktbl.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
       
    }//GEN-LAST:event_cookActionPerformed

    private void cooktblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cooktblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_cooktblMouseClicked

    private void cooktblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cooktblKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_cooktblKeyReleased

    private void backbt5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt5ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt5ActionPerformed

    private void japanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_japanActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS  ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'Japan' ";
                pst = conn.prepareStatement(sql); //connect variables
                rs = pst.executeQuery(); // connect variables

                japantbl.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_japanActionPerformed

    private void japantblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_japantblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_japantblMouseClicked

    private void japantblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_japantblKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_japantblKeyReleased

    private void backbt6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt6ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt6ActionPerformed

    private void fdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fdActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "SELECT id AS ID , fname AS FullName , namei AS NameWithInitials, nic AS NIC, gender AS Gender, address AS Address, phoneno AS PhoneNo, cname AS CustodiansName, ctpn AS CustodiansPhoneNo , courseName AS CourseName FROM student WHERE courseName = 'Fasion Design' "; //create query (table eke display kirimata awashya title pamanak add kala haka.
                pst = conn.prepareStatement(sql); //connect variables
                rs = pst.executeQuery(); // connect variables

                fdtbl.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    }//GEN-LAST:event_fdActionPerformed

    private void fdtblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fdtblMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_fdtblMouseClicked

    private void fdtblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fdtblKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_fdtblKeyReleased

    private void backbt7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbt7ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_backbt7ActionPerformed

    private void snicboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_snicboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_snicboxActionPerformed

    private void sfnameboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sfnameboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sfnameboxActionPerformed

    private void smaleboxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_smaleboxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_smaleboxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mainframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mainframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mainframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainframe.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainframe().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbt1;
    private javax.swing.JButton backbt2;
    private javax.swing.JButton backbt3;
    private javax.swing.JButton backbt4;
    private javax.swing.JButton backbt5;
    private javax.swing.JButton backbt6;
    private javax.swing.JButton backbt7;
    private javax.swing.JButton backbt8;
    private javax.swing.JButton bridal;
    private javax.swing.JButton bridalbtn;
    private javax.swing.JTable bridaltbl;
    private javax.swing.JButton cook;
    private javax.swing.JButton cookbtn;
    private javax.swing.JTable cooktbl;
    private javax.swing.JButton english;
    private javax.swing.JButton englishbtn;
    private javax.swing.JTable englishtbl;
    private javax.swing.JButton fasiondesignbtn;
    private javax.swing.JButton fd;
    private javax.swing.JTable fdtbl;
    private javax.swing.ButtonGroup gendergrp;
    private javax.swing.JButton hairbeautybtn;
    private javax.swing.JButton hb;
    private javax.swing.JTable hbtbl;
    private javax.swing.JButton ictbtn;
    private javax.swing.JTable icttbl;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton japan;
    private javax.swing.JButton japanbtn;
    private javax.swing.JTable japantbl;
    private javax.swing.JButton logoutbtn1;
    private javax.swing.JTextField saddressbox;
    private javax.swing.JButton sclearbtn;
    private javax.swing.JTextField scnamebox;
    private javax.swing.JComboBox scorsenamebox;
    private javax.swing.JTextField scphonebox;
    private javax.swing.JButton sdeletebtn;
    private javax.swing.JRadioButton sfemalebox;
    private javax.swing.JTextField sfnamebox;
    private javax.swing.ButtonGroup sgendergrp;
    private javax.swing.JTextField sidbox;
    private javax.swing.JButton sinsertbtn;
    private javax.swing.JRadioButton smalebox;
    private javax.swing.JTextField snamebox;
    private javax.swing.JTextField snicbox;
    private javax.swing.JTextField sphonebox;
    private javax.swing.JTextField ssearchbox;
    private javax.swing.JButton supdatebtn;
    private javax.swing.JTable table3;
    private javax.swing.JButton tamil;
    private javax.swing.JTable tamilbtn;
    private javax.swing.JButton tmilbtn;
    private javax.swing.JButton viewbtn1;
    // End of variables declaration//GEN-END:variables

}
